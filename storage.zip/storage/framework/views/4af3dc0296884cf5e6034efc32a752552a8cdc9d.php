
<?php $__env->startSection('content'); ?>
<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title">Tabel Data Whistleblowing System BKSDA</h4>
						<ul class="breadcrumbs">
							<li class="nav-home">
								<a href="<?php echo e(Route('admin-view')); ?>">
									<i class="flaticon-home"></i>
								</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								<a href="#">Tabel Data Laporan</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								<a href="<?php echo e(Route('jenis.benturan')); ?>">Benturan kepentingan</a>
							</li>
						</ul>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<!-- Tabel Laporan -->
									<div class="table-responsive">
										<table id="add-row" class="display table table-striped table-hover" >
                                            <thead>
												<tr>
													<th>No</th>
													<th>Judul</th>
													<th>Nama Pelapor</th>
													<th>Status</th>
													<th>Tanggal Masuk</th>
													<th>Terakhir Diubah</th>
													<th style="text-align:center">Tindakan</th>
												</tr>
											</thead>
                                            <tbody>
											<?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr>
													<td><?php echo e(++$no + ($laporans->currentPage()-1) * $laporans->perPage()); ?></td>
													<td><?php echo e($laporan->judul); ?></td>
													<td><?php echo e($laporan->namapelapor); ?></td>
													<td><?php echo e($laporan->status); ?></td>
													<td><?php echo e($laporan->created_at); ?></td>
													<td><?php echo e($laporan->updated_at); ?></td>
													<td>
														<div class="form-button-action">
															<button class="btn btn-link btn-primary btn-lg"><a class="fa fa-eye" href="<?php echo e(route('laporans.show',$laporan->id)); ?>"> Tampilkan</a></button>
															<button class="btn btn-link btn-primary btn-lg"><a class="fa fa-edit" href="<?php echo e(route('laporans.edit',$laporan->id)); ?>"> Edit</a></button>
															<!--<form action="<?php echo e(route('laporans.destroy',$laporan->id)); ?>" method="POST">
																<button type="submit"class="btn btn-link btn-danger"><a class="fa fa-trash"><?php echo csrf_field(); ?>
																<?php echo method_field('DELETE'); ?> Hapus</a></button>
															</form>-->
														</div>
													</td>
												</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
										</table>
										<?php echo e($laporans->links()); ?>

									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
<!-- batas 
<div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h1><strong>Daftar Laporan</strong></h1>
            </div>
        </div>
    </div>


    <table class="table table-bordered">
        <tr>
            <th>Judul</th>
            <th>Nama Pelapor</th>
            <th>Email</th>
            <th>Jenis Pelanggaran</th>
            <th>Nama Terlapor</th>
            <th>Lokasi Kejadian</th>
            <th>Kota</th>
            <th>Provinsi</th>
            <th>Tanggal</th>
            <th>Waktu</th>
            <th>Uraian</th>
            <th>Bukti</th>
        </tr>
        <?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($laporan->judul); ?></td>
            <td><?php echo e($laporan->namapelapor); ?></td>
            <td><?php echo e($laporan->email); ?></td>
            <td><?php echo e($laporan->jenispelanggaran); ?></td>
            <td><?php echo e($laporan->namaterlapor); ?></td>
            <td><?php echo e($laporan->lokasi); ?></td>
            <td><?php echo e($laporan->kota); ?></td>
            <td><?php echo e($laporan->provinsi); ?></td>
            <td><?php echo e($laporan->tanggal); ?></td>
            <td><?php echo e($laporan->waktu); ?></td>
            <td><?php echo e($laporan->uraian); ?></td>
            <td>Lihat Bukti</td>   
            <td>
                <form action="<?php echo e(route('laporans.destroy',$laporan->id)); ?>" method="POST">
                    <a class="btn btn-info" href="<?php echo e(route('laporans.show',$laporan->id)); ?>">Show</a>
                    <a class="btn btn-primary" href="<?php echo e(route('laporans.edit',$laporan->id)); ?>">Edit</a>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\WBS_BKSDA\resources\views/jenis/benturan.blade.php ENDPATH**/ ?>