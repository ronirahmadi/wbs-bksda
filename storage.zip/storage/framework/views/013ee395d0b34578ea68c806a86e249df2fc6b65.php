<?php $__env->startSection('content'); ?>
<div class="contact">
    <div class="container">
        <div class="section-header">
            <h2>Form Laporan</h2>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="faqs">
                    <div id="accordion">
                        <div class="card">
                            <div class="card-header">
                                <a class="card-link collapsed" data-toggle="collapse" href="#collapseOne" aria-expanded="true">
                                    <span>1</span> Apa itu WBS BKSDA?
                                </a>
                            </div>
                            <div id="collapseOne" class="collapse show" data-parent="#accordion">
                                <div class="card-body">
                                Whistleblowing System adalah aplikasi yang disediakan oleh Badan Konservasi Sumber Daya Alam bagi Anda yang memiliki informasi dan ingin melaporkan suatu perbuatan berindikasi pelanggaran yang mengancam kepunahan satwa dilindungi.
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <a class="card-link" data-toggle="collapse" href="#collapseTwo">
                                    <span>2</span> Apa Manfaat Whistleblowing System?
                                </a>
                            </div>
                            <div id="collapseTwo" class="collapse" data-parent="#accordion">
                                <div class="card-body">
                                Karena Whistleblowing mencakup budaya transparan yang mendorong pelaporan suatu pelanggaran. Selain transparansi, BKSDA memastikan bahwa sistem whistleblowing melindungi kerahasiaan pelapor. Sehingga pelapor merasa cukup aman dari segala bentuk pembalasan untuk melaporkan kekhawatirannya.
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <a class="card-link" data-toggle="collapse" href="#collapseThree">
                                    <span>3</span> Bagaimana Penanganan Laporan?
                                </a>
                            </div>
                            <div id="collapseThree" class="collapse" data-parent="#accordion">
                                <div class="card-body">
                                Setelah laporan diterima Tim WBS akan memproses laporan kemudian melakukan validasi laporan, laporan “bukan pelanggaran” atau “sampah” akan dihapuskan dari Sistem WBS sedangkan laporan yang dikategorikan sebagai “pelanggaran” akan ditindaklanjuti. 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="contact-form">
                    <form action="<?php echo e(route('laporans.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Judul:</strong>
                                    <input type="text" name="judul" class="form-control" placeholder="Judul">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Nama Pelapor:</strong>
                                    <input type="text" name="namapelapor" class="form-control" placeholder="Pelapor">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Email:</strong>
                                    <input type="email" name="email" class="form-control" placeholder="E-Mail">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Jenis Pelanggaran:</strong>
                                    <select name="jenispelanggaran" style="width:100%;" onchange="javascript:data_isi()">
                                    <option value="">-- PILIHAN JAWABAN --</option>
                                    <option value="Jual Macan">Jual Hewan</option>
                                    <option value="Beli MAcan">Beli Hewan</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Nama Terlapor:</strong>
                                    <input type="text" name="namaterlapor" class="form-control" placeholder="Nama Terlapor">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Lokasi Kejadian:</strong>
                                    <input type="text" name="lokasi" class="form-control" placeholder="Jalan Abogoboga">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Kota:</strong>
                                    <input type="text" name="kota" class="form-control" placeholder="Kota/Kabupaten">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Provinsi:</strong>
                                    <input type="text" name="provinsi" class="form-control" placeholder="Provinsi">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Tanggal:</strong>
                                    <input type="date" name="tanggal" class="form-control" placeholder="Tanggal">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Waktu:</strong>
                                    <input type="text" name="waktu" class="form-control" placeholder="Bulan Januari Awal">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                <strong>uraian:</strong>
                                    <textarea class="form-control" style="height:150px" name="uraian" placeholder="Description"></textarea>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Contact End -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/WBS_BKSDA/resources/views/lapor.blade.php ENDPATH**/ ?>