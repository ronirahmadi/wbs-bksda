<?php $__env->startSection('content'); ?>
    <div class="s009">
      <form method="GET" action="/pantau">
        <div class="inner-form">
          <div class="basic-search">
            <div class="input-field">
              <input name="cari" type="text" placeholder="Masukkan kode unik anda"/>
              <div class="icon-wrap">
                <svg class="svg-inline--fa fa-search fa-w-16" fill="#ccc" aria-hidden="true" data-prefix="fas" data-icon="search" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                  <path d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"></path>
                </svg>
              </div>
            </div>
          </div>
          <div class="row third">
            <div class="input-field">
              <div class="group-btn">
                <button class="btn-delete" href="<?php echo e(route('pantau')); ?>">RESET</button>
                <button class="btn-search" type="submit">CARI</button>
              </div>
            </div>
          </div>
		  <?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <!-- Single Page Start -->
          <div class="single">
                <div class="container">
                    <div class="section-header">
                        <p>Detail dari Laporan</p>
                        <h2 style="font-weight:bold"><?php echo e($laporan->judul); ?></h2>
                    </div>
                    <div class="row">
                        <div class="col-12">
                          <ul class="list-group">
                              <li class="list-group-item">Nama Pelapor : <?php echo e($laporan->namapelapor); ?></li>
                              <li class="list-group-item">Kode Unik : <?php echo e($laporan->kodeunik); ?></li>
                              <li class="list-group-item">Status Laporan : <?php echo e($laporan->status); ?></li>
                              <li class="list-group-item">Email Pelapor : <?php echo e($laporan->email); ?></li>
                              <li class="list-group-item">Jenis Pelanggaran : <?php echo e($laporan->jenispelanggaran); ?></li>
                              <li class="list-group-item">Nama Terlapor : <?php echo e($laporan->namaterlapor); ?></li>
                              <li class="list-group-item">Tanggal Kejadian : <?php echo e($laporan->tanggal); ?></li>
                              <li class="list-group-item">Lokasi Kejadian : <?php echo e($laporan->lokasi); ?></li>
                              <li class="list-group-item">Kota/Kabupaten : <?php echo e($laporan->kota); ?></li>
                              <li class="list-group-item">Provinsi : <?php echo e($laporan->provinsi); ?></li>
                              <li class="list-group-item">Waktu Kejadian : <?php echo e($laporan->waktu); ?></li>
                              <li class="list-group-item">Tanggal dan Waktu Laporan Masuk : <?php echo e($laporan->created_at); ?></li>
                              <li class="list-group-item">Uraian : <?php echo e($laporan->uraian); ?></li>
                          </ul>                          
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Page End -->
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </form>
    </div>
    <script src="js/extention/choices.js"></script>
    <script>
      const customSelects = document.querySelectorAll("select");
      const deleteBtn = document.getElementById('delete')
      const choices = new Choices('select',
      {
        searchEnabled: false,
        itemSelectText: '',
        removeItemButton: true,
      });
      deleteBtn.addEventListener("click", function(e)
      {
        e.preventDefault()
        const deleteAll = document.querySelectorAll('.choices__button')
        for (let i = 0; i < deleteAll.length; i++)
        {
          deleteAll[i].click();
        }
      });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\WBS_BKSDA\resources\views/pantau.blade.php ENDPATH**/ ?>