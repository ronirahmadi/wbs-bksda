<?php $__env->startSection('content'); ?>
<!-- Page Header Start -->
<div class="container mt-2 mb-2">
      <img src="img/kriterialaporan.jpg" alt="" style="width: 100%;">
      <img src="img/alurlaporan.jpg" alt="" style="width: 100%;">           
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/WBS_BKSDA/resources/views/informasi.blade.php ENDPATH**/ ?>