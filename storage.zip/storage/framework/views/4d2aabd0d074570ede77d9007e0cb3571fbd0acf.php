<?php $__env->startSection('content'); ?>
<div class="contact">
    <div class="container">
        <div class="section-header">
            <h2>Form Laporan</h2>
        </div>
        <form action="<?php echo e(route('laporans.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
            <div class="row">
                
                <div class="col-md-6">
                    <div class="contact-form">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Judul:</strong>
                                    <input type="text" name="judul" class="form-control" placeholder="(Judul dari isi yang dilaporkan)">
                                    <p>Contoh : Transaksi Kulit Harimau Sumatra</p>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Nama Pelapor:</strong>
                                    <input type="text" name="namapelapor" class="form-control" placeholder="(Gunakan nama samaran)">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Email:</strong>
                                    <input type="email" name="email" class="form-control" placeholder="(Boleh dikosongi / tidak diisi)">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Jenis Pelanggaran:</strong>
                                    <input type="text" name="jenispelanggaran" class="form-control" placeholder="(Jenis pelanggaran yang dilakukan)">
                                    <p>Contoh : Menangkap dan Menyiksa Satwa Dilindungi</p>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Nama Terlapor:</strong>
                                    <input type="text" name="namaterlapor" class="form-control" placeholder="(Dapat diisi lebih dari satu nama)">
                                    <p>Jika tidak mengetahui identitas terlapor, tuliskan ciri-ciri pelaku</p>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Lokasi Kejadian:</strong>
                                    <input type="text" name="lokasi" class="form-control" placeholder="Detail nama tempat/alamat kejadian">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="contact-form">
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Kota:</strong>
                                <input type="text" name="kota" class="form-control" placeholder="(Nama Kota/Kabupaten)">
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Provinsi:</strong>
                                <input type="text" name="provinsi" class="form-control" placeholder="(Nama Provinsi)">
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Tanggal Kejadian:</strong>
                                <input type="date" name="tanggal" class="form-control">
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Waktu:</strong>
                                <input type="text" name="waktu" class="form-control" placeholder="Detail waktu perkiraan kejadian">
                                <p>Contoh : Hari senin sore, Minggu Pertama Januari 2021, Saat acara Pet Expo 2021.</p>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                            <strong>Uraian:</strong>
                                <textarea class="form-control" style="height:150px" name="uraian" placeholder="Keterangan/Detail dari kejadian tersebut"></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <input type="file" name="file" class="form-control<?php echo e($errors->has('file') ? ' is-invalid' : ''); ?>" >
                            <?php if($errors->has('file')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('file')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">Kirim Laporan</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/WBS_BKSDA/resources/views/laporans/create.blade.php ENDPATH**/ ?>