
<?php $__env->startSection('content'); ?>
<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title">Tabel Data Whistleblowing System BKSDA</h4>
						<ul class="breadcrumbs">
							<li class="nav-home">
								<a href="<?php echo e(Route('admin-view')); ?>">
									<i class="flaticon-home"></i>
								</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								<a href="<?php echo e(Route('laporans.index')); ?>">Tabel Data Laporan</a>
							</li>
						</ul>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<!-- Tabel Laporan -->
									<div class="table-responsive">
										<table id="add-row" class="display table table-striped table-hover" >
                                            <thead>
												<tr>
													<th>No</th>													
													<th>Nama</th>
                                                    <th>Email</th>
                                                    <th>Judul</th>
													<th>Keterangan</th>
													<th>Tanggal Masuk</th>
													<th style="text-align:center">Tindakan</th>
												</tr>
											</thead>
                                            <tbody>
											<?php $__currentLoopData = $bantuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bantuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr>
													<td><?php echo e($bantuan->id); ?></td>
													<td><?php echo e($bantuan->nama); ?></td>
													<td><?php echo e($bantuan->email); ?></td>
													<td><?php echo e($bantuan->judul); ?></td>
                                                    <td><?php echo e($bantuan->keterangan); ?></td>
													<td><?php echo e($bantuan->created_at); ?></td>
													<td>
														<div class="form-button-action">
															<!-- belum terdeteksi auto reply -->
															<button class="btn btn-link btn-primary btn-lg"><a class="fa fa-reply" href="mailto:$bantuans->email"> Kirim Tanggapan</a></button>
														</div>
													</td>
												</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\WBS_BKSDA\resources\views/kritiksaran.blade.php ENDPATH**/ ?>