<?php $__env->startSection('content'); ?>
<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title">Detail Laporan</h4>
						<ul class="breadcrumbs">
							<li class="nav-home">
								<a href="<?php echo e(route('admin-view')); ?>">
									<i class="flaticon-home"></i>
								</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								<a href="<?php echo e(Route('laporans.index')); ?>">Tabel Data Laporan</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								<a href="">Nomor ID <?php echo e($laporan->id); ?></a>
							</li>
						</ul>
					</div>
					<div class="page-category">
						<div class="row">
							<div class="col-xs-12 col-sm-12 col-md-12">
								<div class="form-group">
									<strong>Judul:</strong>
									<?php echo e($laporan->judul); ?>

								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12">
								<div class="form-group">
									<strong>Tanggal Kejadian:</strong>
									<?php echo e($laporan->tanggal); ?>

								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12">
								<div class="form-group">
									<strong>Nama Pelapor:</strong>
									<?php echo e($laporan->namapelapor); ?>

								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12">
								<div class="form-group">
									<strong>Kode Unik:</strong>
									<?php echo e($laporan->kodeunik); ?>

								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12">
								<div class="form-group">
									<strong>Email:</strong>
									<?php echo e($laporan->email); ?>

								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12">
								<div class="form-group">
									<strong>Jenis Pelanggaran:</strong>
									<?php echo e($laporan->jenispelanggaran); ?>

								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12">
								<div class="form-group">
									<strong>Nama Terlapor:</strong>
									<?php echo e($laporan->namaterlapor); ?>

								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12">
								<div class="form-group">
									<strong>Lokasi:</strong>
									<?php echo e($laporan->lokasi); ?>

								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12">
								<div class="form-group">
									<strong>Kota:</strong>
									<?php echo e($laporan->provinsi); ?>

								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12">
								<div class="form-group">
									<strong>Waktu Kejadian:</strong>
									<?php echo e($laporan->judul); ?>

								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12">
								<div class="form-group">
									<strong>Uraian:</strong>
									<?php echo e($laporan->uraian); ?>

								</div>
							</div>

							<div class="col-xs-12 col-sm-12 col-md-12">
								<div class="form-group">
									<strong>Bukti:</strong><a target="_blank" href="<?php echo e(url('storage/uploads/')); ?>/<?php echo e($laporan->name); ?>" download>
									Unduh Bukti</a>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12">
								<div class="form-group">
									<strong>Status:</strong><a>
									<?php echo e($laporan->status); ?></a>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-12 margin-tb">
								<div class="pull-right">
									<a class="btn btn-primary" href="<?php echo e(route('laporans.index')); ?>"> Back</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/WBS_BKSDA/resources/views/laporans/show.blade.php ENDPATH**/ ?>