
<?php $__env->startSection('content'); ?>
<!-- dropdown.blade.php -->
    <div class="container">
    <h2>Laravel Dependent Dropdown  Tutorial With Example</h2>
            <div class="form-group">
                <label for="provinsi">Select Provinsi:</label>
                <select name="provinsi" class="form-control" style="width:250px">
                    <option value="">--- Select Provinsi ---</option>
                    <?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="kota">Select Kota/Kabupaten:</label>
                <select name="kota" class="form-control"style="width:250px">
                <option>Kota/Kabupaten</option>
                </select>
            </div>
            <div class="form-group">
                <label for="kecamatan">Select Kecamatan:</label>
                <select name="kecamatan" class="form-control"style="width:250px">
                <option>--Kecamatan--</option>
                </select>
            </div>
            <div class="form-group">
                <label for="kelurahan">Select Kelurahan:</label>
                <select name="kelurahan" class="form-control"style="width:250px">
                <option>--Kelurahan--</option>
                </select>
            </div>                  
      </div>
    <script type="text/javascript">
    //kabupaten
    jQuery(document).ready(function ()
    {
            jQuery('select[name="provinsi"]').on('change',function(){
               var provinsiID = jQuery(this).val();
               if(provinsiID)
               {
                  jQuery.ajax({
                     url : 'dropdownlist/getstates/' +provinsiID,
                     type : "GET",
                     dataType : "json",
                     success:function(data)
                     {
                        console.log(data);
                        jQuery('select[name="kota"]').empty();
                        jQuery.each(data, function(key,value){
                           $('select[name="kota"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                     }
                  });
               }
               else
               {
                  $('select[name="kota"]').empty();
               }
            });
    });
    //kecamatan
    jQuery(document).ready(function ()
    {
            jQuery('select[name="kota"]').on('change',function(){
               var kotaID = jQuery(this).val();
               if(kotaID)
               {
                  jQuery.ajax({
                     url : 'dropdownlist/getkec/' +kotaID,
                     type : "GET",
                     dataType : "json",
                     success:function(data)
                     {
                        console.log(data);
                        jQuery('select[name="kecamatan"]').empty();
                        jQuery.each(data, function(key,value){
                           $('select[name="kecamatan"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                     }
                  });
               }
               else
               {
                  $('select[name="kecamatan"]').empty();
               }
            });
    });
    //kelurahan
    jQuery(document).ready(function ()
    {
            jQuery('select[name="kecamatan"]').on('change',function(){
               var kecamatanID = jQuery(this).val();
               if(kecamatanID)
               {
                  jQuery.ajax({
                     url : 'dropdownlist/getdes/' +kecamatanID,
                     type : "GET",
                     dataType : "json",
                     success:function(data)
                     {
                        console.log(data);
                        jQuery('select[name="kelurahan"]').empty();
                        jQuery.each(data, function(key,value){
                           $('select[name="kelurahan"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                     }
                  });
               }
               else
               {
                  $('select[name="kelurahan"]').empty();
               }
            });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\WBS_BKSDA\resources\views/dropdown.blade.php ENDPATH**/ ?>