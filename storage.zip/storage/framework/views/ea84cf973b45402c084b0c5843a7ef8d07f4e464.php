<?php $__env->startSection('content'); ?>
    <!-- Portfolio Start -->
<div class="portfolio">
    <div class="container">
        <div class="section-header">
            <p>Daftar Satwa</p>
            <h2>Dilindungi</h2>
        </div>
        <div class="row portfolio-container">
        <?php $__currentLoopData = $satwas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $satwa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 col-sm-12 portfolio-item">
                <div class="portfolio-wrap">
                    <figure>
                        <img src="<?php echo e(url('img/satwa')); ?>/<?php echo e($satwa->gambar); ?>" alt="Portfolio Image">
                        <a href="<?php echo e(url('img/satwa')); ?>/<?php echo e($satwa->gambar); ?>" class="link-preview" data-lightbox="portfolio"><i class="fa fa-eye"></i></a>
                        <a class="portfolio-title" href="#"><?php echo e($satwa->nama); ?></a>
                    </figure>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo e($satwas->links()); ?>

    </div>
</div>
<!-- Portfolio End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\WBS_BKSDA\resources\views/satwa.blade.php ENDPATH**/ ?>