
<?php $__env->startSection('content'); ?>
<!-- Single Page Start -->
<div class="single">
                <div class="container">
                    <div class="section-header">
                        <p>Kode Unik Anda</p>
                        <h2 style="font-weight:bold"><?php echo e($laporan->kodeunik); ?></h2>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <h3>Detail Laporan Anda</h3> 
                            <ul class="list-group">
                              <li class="list-group-item">Nama Pelapor : <?php echo e($laporan->namapelapor); ?></li>
                              <li class="list-group-item">Status Laporan : <?php echo e($laporan->status); ?></li>
                              <li class="list-group-item">Email Pelapor : <?php echo e($laporan->email); ?></li>
                              <li class="list-group-item">Jenis Pelanggaran : <?php echo e($laporan->jenispelanggaran); ?></li>
                              <li class="list-group-item">Nama Terlapor : <?php echo e($laporan->namaterlapor); ?></li>
                              <li class="list-group-item">Tanggal Kejadian : <?php echo e($laporan->tanggal); ?></li>
                              <li class="list-group-item">Lokasi Kejadian : <?php echo e($laporan->lokasi); ?></li>
                              <li class="list-group-item">Kota/Kabupaten : <?php echo e($laporan->kota); ?></li>
                              <li class="list-group-item">Provinsi : <?php echo e($laporan->provinsi); ?></li>
                              <li class="list-group-item">Waktu Kejadian : <?php echo e($laporan->waktu); ?></li>
                              <li class="list-group-item">Tanggal dan Waktu Laporan Masuk : <?php echo e($laporan->created_at); ?></li>
                              <li class="list-group-item">Uraian : <?php echo e($laporan->uraian); ?></li>
                              <li class="list-group-item">Bukti: <a target="_blank" href="<?php echo e(url('storage/uploads/')); ?>/<?php echo e($laporan->name); ?>" download>Unduh Bukti</a></li>
                            </ul>
                            <div class="tombol-tutup">
                                <a class="btn btn-primary" style="color:white;" href="<?php echo e(route('lapor')); ?>">Kembali</a>
                            </div>                         
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Page End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\WBS_BKSDA\resources\views/detail-lapor.blade.php ENDPATH**/ ?>