<?php $__env->startSection('content'); ?>
<div class="main-panel">
	<div class="content">
		<div class="panel-header bg-primary-gradient">
			<div class="page-inner py-5">
				<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
					<div>
						<h2 class="text-white pb-2 fw-bold">Dashboard</h2>
						<h5 class="text-white op-7 mb-2">Selamat Datang di Halaman Admin Whistleblowing System BKSDA</h5>
					</div>
				</div>
			</div>
		</div>
		<div class="page-inner mt--5">
			<div class="row row-card-no-pd mt--2">
				<div class="col-sm-6 col-md-3">
					<div class="card card-stats card-round">
						<div class="card-body ">
							<div class="row">
								<div class="col-5">
									<div class="icon-big text-center">
										<i class="flaticon-message text-warning"></i>
									</div>
								</div>
								<div class="col-7 col-stats">
									<div class="numbers">
										<p class="card-category">Laporan Masuk</p>
										<h4 class="card-title"><?php echo e($total); ?></h4>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-6 col-md-3">
					<div class="card card-stats card-round">
						<div class="card-body ">
							<div class="row">
								<div class="col-5">
									<div class="icon-big text-center">
										<i class="flaticon-success text-success"></i>
									</div>
								</div>
								<div class="col-7 col-stats">
									<div class="numbers">
										<p class="card-category">Diproses</p>
										<h4 class="card-title"><?php echo e($diproses); ?></h4>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-6 col-md-3">
					<div class="card card-stats card-round">
						<div class="card-body">
							<div class="row">
								<div class="col-5">
									<div class="icon-big text-center">
										<i class="flaticon-error text-danger"></i>
									</div>
								</div>
								<div class="col-7 col-stats">
									<div class="numbers">
										<p class="card-category">Ditolak</p>
										<h4 class="card-title"><?php echo e($ditolak); ?></h4>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-6 col-md-3">
					<div class="card card-stats card-round">
						<div class="card-body">
							<div class="row">
								<div class="col-5">
									<div class="icon-big text-center">
										<i class="flaticon-list text-primary"></i>
									</div>
								</div>
								<div class="col-7 col-stats">
									<div class="numbers">
										<p class="card-category">Perlu Verifikasi</p>
										<h4 class="card-title"><?php echo e($belumdiverifikasi); ?></h4>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="page-inner mt--5">
				<div class="row">
					<div class="col-md-8">
						<div class="card">
							<div class="card-header">
								<div class="card-head-row">
									<div class="card-title">Grafik Data Laporan Per Tahun</div>
									<div class="card-tools">
										<a href="#" class="btn btn-info btn-border btn-round btn-sm mr-2">
											<span class="btn-label">
												<i class="fa fa-file-export"></i>
											</span>
											Export
										</a>
										<a href="#" class="btn btn-info btn-border btn-round btn-sm">
											<span class="btn-label">
												<i class="fa fa-print"></i>
											</span>
											Print
										</a>
									</div>
								</div>
							</div>
							<div class="card">
								<canvas id="Chart1" style="width: 100%;"></canvas>
								<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.5.0/chart.min.js"></script>
								<script type="text/javascript">
								
								//ambil data laporan
								var grafiklaporans =  <?php echo json_encode($grafiklaporans) ?>;
								var grafiklaporansdiproses =  <?php echo json_encode($grafiklaporansdiproses) ?>;
								var grafiklaporansditolak =  <?php echo json_encode($grafiklaporansditolak) ?>;
								
								//eksekusi data laporan
								var ctx = document.getElementById('Chart1').getContext('2d');
								var grafiklaporans = new Chart(ctx, {
									type: 'line',
									data: {
										labels: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'],
										datasets: [ {
										label: "Laporan Masuk",
											data: grafiklaporans,
											fill: false,
											borderColor: 'rgba(253, 175, 75, 0.6)',
											backgroundColor: 'rgba(253, 175, 75, 0.4)',
											legendColor: '#fdaf4b',
											tension: 0.1
										}, {
										label: "Laporan Diproses",
											data: grafiklaporansdiproses,
											fill: false,
											borderColor: 'rgba(0, 255, 0, 0.6)',
											backgroundColor: 'rgba(0, 255, 0, 0.4)',
											legendColor: '#00ff00',
											tension: 0.1
										}, {
										label: "Laporan Ditolak",
										data: grafiklaporansditolak,
											fill: false,
											borderColor: 'rgba(243, 84, 93, 0.6)',
											backgroundColor: 'rgba(243, 84, 93, 0.4)',
											legendColor: '#f3545d',
											tension: 0.1
										}]
									},
									options: {
										scales: {
											y: {
												beginAtZero: true
											}
										},
									}
								});
								</script>	
							</div>
						</div>
					</div>
				</div>
				<div class="row row-card-no-pd">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<div class="card-head-row card-tools-still-right">
									<h4 class="card-title">Sebaran Provinsi Berdasarkan Laporan Masuk</h4>
									<div class="card-tools">
									<button class="btn btn-icon btn-link btn-primary btn-xs btn-refresh-card"><span class="fa fa-sync-alt"></span></button>
										<button class="btn btn-icon btn-link btn-primary btn-xs"><span class="fa fa-file-export"></span></button>
										<button class="btn btn-icon btn-link btn-primary btn-xs"><span class="fa fa-print"></span></button>
									</div>
								</div>
								<p class="card-category">
								Berdasarkan data laporan setiap provinsi</p>
							</div>
							<div class="card-body">
								<div class="row">
									<div class="col-md-5">
										<div class="table-responsive table-hover table-sales">
											<table class="table">
												<tbody>
													<tr>
														<td>
															<div class="flag">
																<img src="../assets/img/flags/id.png" alt="indonesia">
															</div>
														</td>
														<td>Indonesia</td>
													</tr>
													
												</tbody>
											</table>
										</div>
									</div>
									<div class="col-md-7">
										<canvas id="Chart2"></canvas>
										<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.5.0/chart.min.js"></script>
										<script type="text/javascript">
										
										//ambil data provinsi
										var Aceh =  <?php echo json_encode($AC) ?>;
										var Bali =  <?php echo json_encode($BA) ?>;
										var Banten =  <?php echo json_encode($BT) ?>;
										var Bengkulu =  <?php echo json_encode($BE) ?>;
										var Jogja =  <?php echo json_encode($YO) ?>;
										var Jakarta =  <?php echo json_encode($JK) ?>;
										var Gorontalo =  <?php echo json_encode($GO) ?>;
										var Jambi =  <?php echo json_encode($JA) ?>;
										var JawaBarat =  <?php echo json_encode($JB) ?>;
										var JawaTengah =  <?php echo json_encode($JT) ?>;
										var JawaTimur =  <?php echo json_encode($JI) ?>;
										var KalimantanBarat =  <?php echo json_encode($KB) ?>;
										var KalimantanSelatan =  <?php echo json_encode($KS) ?>;
										var KalimantanTengah =  <?php echo json_encode($KT) ?>;
										var KalimantanTimur =  <?php echo json_encode($KI) ?>;
										var KalimantanUtara =  <?php echo json_encode($KU) ?>;
										var KepBangka =  <?php echo json_encode($BB) ?>;
										var KepRiau =  <?php echo json_encode($KR) ?>;
										var Lampung =  <?php echo json_encode($LA) ?>;
										var Maluku =  <?php echo json_encode($MA) ?>;
										var MalukuUtara =  <?php echo json_encode($MU) ?>;
										var NusaTenggaraBarat =  <?php echo json_encode($NB) ?>;
										var NusaTenggaraTimur =  <?php echo json_encode($NT) ?>;
										var Papua =  <?php echo json_encode($PA) ?>;
										var PapuaBarat =  <?php echo json_encode($PB) ?>;
										var Riau =  <?php echo json_encode($RI) ?>;
										var SulawesiBarat =  <?php echo json_encode($SR) ?>;
										var SulawesiSelatan =  <?php echo json_encode($SN) ?>;
										var SulawesiTengah =  <?php echo json_encode($ST) ?>;
										var SulawesiTenggara =  <?php echo json_encode($SG) ?>;
										var SulawesiUtara =  <?php echo json_encode($SA) ?>;
										var SumatraBarat =  <?php echo json_encode($SB) ?>;
										var SumatraSelatan =  <?php echo json_encode($SS) ?>;
										var SumatraUtara =  <?php echo json_encode($SU) ?>;
										
										//eksekusi data provinsi
										var ctx = document.getElementById('Chart2').getContext('2d');
										var grafikprovinsi = new Chart(ctx, {
											type: 'pie',
											data: {
												labels: [
													'Aceh','Bali', 'Banten', 'Bengkulu', 'DIY', 'DKI Jakarta', 'Gorontalo', 'Jambi', 'Jabar', 'Jateng', 'Jatim', 'Kalbar', 'Kalsel', 'Kalteng', 'Kaltim', 'Kaltara', 'Babel', 'Kepri', 'Lampung', 'Maluku', 'Malut', 'NTB', 'NTT', 'Papua', 'Pabar', 'Riau', 'Sulbar', 'Sulsel', 'Sulteng', 'Sultra', 'Sulut', 'Sumbar', 'Sumsel', 'Sumut'
													
												],
												datasets: [{
													label: 'Data Provinsi',
													data: [Aceh, Bali, Banten, Bengkulu, Jogja, Jakarta, Gorontalo, Jambi, JawaBarat, JawaTengah, JawaTimur, KalimantanBarat, KalimantanSelatan, KalimantanTengah, KalimantanTimur, KalimantanUtara, KepBangka, KepRiau,
														Lampung, Maluku, MalukuUtara, NusaTenggaraBarat, NusaTenggaraTimur, Papua, PapuaBarat, Riau, SulawesiBarat, SulawesiSelatan,SulawesiTengah, SulawesiTenggara, SulawesiUtara,SumatraBarat, SumatraSelatan, SumatraUtara],
													backgroundColor: [
													'#8B0000','#B22222','#FF0000','#DC143C','#FF8C00','#FFA500','#FF7F50','#BC8F8F','#FFFF00','#BDB76B','#F0E68C','#EEE8AA','#7CFC00','#00FF7F','#98FB98','#228B22','#00FFFF','#7FFFD4','#20B2AA','#008B8B','#000080','#1E90FF','#4169E1','	#0000FF','#EE82EE','#FF00FF','#9400D3','#800080','#DAA520','#A0522D','#D2691E','#001514','#808080','#2F4F4F'
													
													],
													hoverOffset: 4
												}]
											}
										});
										</script>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/WBS_BKSDA/resources/views/admin-view.blade.php ENDPATH**/ ?>