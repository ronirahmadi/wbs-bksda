@extends('layouts.app')
@section('content')
<!-- Page Header Start -->
<div class="container mt-2 mb-2">
      <img src="img/kriterialaporan.jpg" alt="" style="width: 100%;">
      <img src="img/alurlaporan.jpg" alt="" style="width: 100%;">           
</div>
@endsection